import React, { Component } from "react"
import '../styles/HomePage.scss';
import MusicPieChart from "../components/MusicPieChart"
import MusicTable from "../components/MusicTable"
import MusicCardTable from "../components/MusicCardTable"

// const REQUEST_URL = "http://group16-hats-and-glasses-backend-development.us-east-1.np.paas.lmig.com";
const REQUEST_URL = "http://localhost:8080";

class HomePage extends Component {

    state = {
        //scores: [],
        scores: {"1.0":3, "2.0":4, "3.0":2, "4.0":6, "5.0":4},
        reviews: [],
        top: []

    }

    constructor(props) {

        super(props);
        this.getScores = this.getScores.bind(this);
        this.getReviews = this.getReviews.bind(this);
        this.getTopTen = this.getTopTen.bind(this);
    }

    //Get list of reviews for table
    getReviews() {

        fetch(REQUEST_URL + '/api/music/reviews?limit=1000&offset=0')
            .then(data => data.json())
            .then(data => this.setState({
                reviews: data
            }))

    }

    //Get list of scores for pie chart
    getScores() {
        fetch(REQUEST_URL + "/api/music/scores")
            .then(data => data.json())
            .then(data => this.setState(
                {scores: data}
            ));
    }

    //Get list of top ten reviewed products
     getTopTen() {

        fetch(REQUEST_URL + '/api/music/product/top')
            .then(data => data.json())
            .then(data => this.setState(
                {top: data}
            ));


     }

    componentDidMount() {
        this.getScores();
        this.getReviews();
        this.getTopTen();
    }

    render() {

        return (
            <div id="home_page">
                <div className = "pieChartHome" style = {{ backgroundColor : "#f6d680", width : "100%", display: "flex", justifyContent:"left"}}>
                    <h1 style = {{ marginLeft : "0.5em" , marginRight : '3em' }}>Total Review Rating Distribution</h1>
                    
                    <MusicPieChart scores={this.state.scores}/>
                </div>
                <div className = "cardTable" style = {{  position:"relative", width : "100%", backgroundColor : "#616265", height : "40em", display: "flex", justifyContent:"center"}}>
                    <h1 style = {{ color: "white", position:"absolute" }}>Top 10 Music:</h1>
                    <MusicCardTable top={this.state.top} />
                </div>
                <div className = "table" style = {{ position:"relative", marginTop: "2em" }}>
                    <MusicTable MusicList ={this.state.reviews}/>
                </div>
            </div>
        )
    }

}
export default HomePage
