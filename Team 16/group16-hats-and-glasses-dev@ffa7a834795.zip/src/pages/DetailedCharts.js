import React, { Component } from 'react'
import MusicForm from '../components/MusicForm';
import '../styles/DetailedCharts.scss';

class DetailedCharts extends Component {

    state = {
        scores: {},
        dates: {}
    }

    // constructor(props) {
    //     super(props);
    // }

    render() {
        return (
            <div id="detailed_charts">
                <div className="form-flex">
                    <MusicForm />
                </div>
            </div>
        )
    }
}

export default DetailedCharts;