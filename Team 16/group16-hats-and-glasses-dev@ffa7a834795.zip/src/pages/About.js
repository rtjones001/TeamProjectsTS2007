import React from 'react';
import '../styles/About.scss';

function AboutPage() {
    return (
        <div id="about-page">
            <div className="container">
                <h1>Amazon Music Reviews Web Application</h1>
                <hr />
                <hr />
                <h3>Front End Developers</h3>
                <hr />
                <ul>
                    <li>Jungyoon Yu</li>
                    <li>Justin Park</li>
                    <li>Dakota Whelchel</li>
                </ul>
                <hr />
                <h3>Back End Developers</h3>
                <hr />
                <ul>
                    <li>Nick Rodriguez</li>
                    <li>Lauren Hager</li>
                    <li>Elizabeth Myers</li>
                </ul>
                <hr />
                <h3>Project Description</h3>
                <hr />
                <p>For our project, we will be creating a web application to 
                    display information about music products sold on Amazon's 
                    e-commerce website. An analytics dashboard will summarize 
                    the data and information about music reviews to provide the 
                    user useful insights into the music sold on Amazon. Our web 
                    application also provides a product detail page which allows
                    users to search and filter by specific information in order 
                    to gain a deeper understanding of individual Amazon music 
                    products through their reviews.</p>
            </div>
        </div>
    )
}

export default AboutPage