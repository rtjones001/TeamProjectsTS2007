import React from 'react';
import './App.css';
import HomePage from './pages/HomePage';
import About from './pages/About';
import DetailedCharts from './pages/DetailedCharts';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import { Switch, Route } from 'react-router-dom';


function App() {
  return (
    <div className="App">
      <Navbar />
      <main>
        <Switch>
          <Route exact path='/' component={HomePage} />
          <Route path='/home' component={HomePage} />
          <Route path='/detailedcharts' component={DetailedCharts} />
          <Route path='/about' component={About} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

export default App;
