import React, { Component } from "react";

class Music extends Component {

  state = {
    music: {
      numOfReviews: "",
      productId : "",
      title: "",
      price: "",
      averageScore: ""
    }
  };
 
  // constructor(props) {
  //   super(props);
  // }

  render() {
    // console.log(this.props.music);

    return (
            <div  style={{ borderStyle: "solid", marginRight : "5em", marginTop : "2em", display: "flex", flexWrap : "wrap", width: "110%", height:"85%" }} className= "card" >
                <div className="card-body"  style={{ backgroundColor: "white", flexWrap : "wrap" }}>
                    <h6  style = {{ verticalAlign: "top", textAlign : "left", color : "black" }}> {this.props.music.productId}</h6>
                    <h5 className="card-title"  style = {{ color : "black", textAlign : "center"}}>{this.props.music.title}</h5>
                    <h6 className="card-subtitle mb-2 text-muted"  style = {{ color : "black",  textAlign : "center" }}>${this.props.music.price}</h6>
                    <h6 className="card-link"  style = {{ color : "black", textAlign : "center" }}>Score: {this.props.music.averageScore}</h6>
                    <h6 className="cardReview"  style = {{ color : "black", textAlign : "center" }}>Number of Reviews: {this.props.music.numOfReviews}</h6>
                </div>
            </div>
    );
  }
}


export default Music;