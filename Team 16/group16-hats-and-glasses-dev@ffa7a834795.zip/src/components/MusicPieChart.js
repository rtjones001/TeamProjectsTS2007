import React, { Component } from 'react'
import { PieChart } from 'react-d3-components'
import "../css/Tooltip.css"

var data = {
    label: 'Total Music Reviews',
    values: [{x: '5 stars', y: 34}, {x: '4 stars', y: 21}, {x: '3 stars', y: 13}, {x: '2 stars', y: 8}, {x: '1 stars', y: 5} ]
};




var sort = null; // d3.ascending, d3.descending, func(a,b) { return a - b; }, etc...

var tooltipBar = function(label, value) {
    return (label + ": " + value);
}

var bla = {"1.0":56, "2.0":46, "3.0":72, "4.0":179, "5.0":646};


class MusicPieChart extends Component {

    constructor (props){
        super(props);
        console.log(this.props);
    }

    scoreParse() {
        const scoreKeys = Object.keys(this.props.scores);
        for (let i = 0; i < 5; i++){
            let tempScoreKey = (scoreKeys[i].charAt(0) + " stars");
            for (let j = 0; j < 5; j++){
                if (data.values[j].x === tempScoreKey){
                    data.values[j].y = this.props.scores[scoreKeys[i]];
                    break;
                }
            }
        }
        // console.log("PIE CHART TESTING: "+ JSON.stringify(data.values))
        return data;
    }

    parseData() {
        this.testData.map((score, i) => {
            let temp = i + ".0";
            console.log(temp);
            let test = score[temp]
            console.log(test);
        })
    }
    render(){
        return (
            <div className="piechart">
                <PieChart
                    data={this.scoreParse()}
                    width={600}
                    height={400}
                    margin={{top: 10, bottom: 10, left: 100, right: 100}}
                    sort={sort}
                    tooltipHtml={tooltipBar}
                />
            </div>
        )
    }
}

export default MusicPieChart
