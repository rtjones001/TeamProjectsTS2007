import React from 'react';
import { Table } from 'react-bootstrap'
import '../css/MusicTable.css'
import '../styles/Input.scss';

const MusicTableHeader = () => {
    return (
        <tr>
            <th>Review ID</th>
            <th>Title</th>
            <th>Price</th>
            <th>Profile Name</th>
            <th>Helpfulness</th>
            <th>Score</th>
            <th>Review Time</th>
            <th>Summary</th>
            <th>Review</th>
        </tr>
    )
}

const MusicTableRow = ({ Music }) => {
    return (
    <tr>
        <td>{Music.ReviewId}</td>
        <td>{Music.Title}</td>
        <td>{Music.Price}</td>
        <td>{Music.ProfileName}</td>
        <td>{Music.Helpfulness}</td>
        <td>{Music.Score}</td>
        <td>{Music.Date}</td>
        <td>{Music.Summary}</td>
        <td>{Music.Text}</td>
    </tr>
    )
}

class MusicTable extends React.Component {
    constructor(props) {
        super(props);
    }

    state = { searchedValue: "" };
    
    static defaultProps = {
        MusicList: [
            {
                "Score": "5.0",
                "Price": null,
                "Helpfulness": "2/3",
                "UserId": "AJ3O6B1YXBEOJ",
                "HelpfulnessRatio": "0",
                "Title": "Singing Brakeman",
                "Summary": "Your best bet......",
                "ProductId": "B000EQ4650",
                "ProfileName": "Ernie Wild \"Eddie\"",
                "Text": "if you are looking for a great overview of Jimmie's career. All the Blue yodels plus many more. Not much else to add. Just a good buy of great music!",
                "ReviewId": "1",
                "Date": "2007-06-13 00:00:00"
            },
            {
                "Score": "4.0",
                "Price": "10.38",
                "Helpfulness": "0/0",
                "UserId": "A199SYBJJ0Y3Y1",
                "HelpfulnessRatio": "0",
                "Title": "Now Here Is Nowhere",
                "Summary": "These guys are not kidding",
                "ProductId": "B0001XARY0",
                "ProfileName": "Arlo Vortex",
                "Text": "The reviewers below? Listen to them. Secret Machines sound like power pop on one song, sonic youth in another, what was the name of that band? Prgressive late 60's early 70's space rock, whatever, This band supposedly moved to NYC but I haven't seen them here at least since I bought this album several months ago. Are they from Texas? They sound like they're english. I can't wait to hear their next release. Or is it too late for them already? If you don't keep your ear to the tracks, you could miss out on a real good thing. Buy now.",
                "ReviewId": "2",
                "Date": "2004-10-25 00:00:00"
            },
            {
                "Score": "3.0",
                "Price": null,
                "Helpfulness": "1/3",
                "UserId": "AR2PDI0J5F55A",
                "HelpfulnessRatio": "0",
                "Title": "Blues Train",
                "Summary": "Big Joe My Main Man",
                "ProductId": "B00008FG06",
                "ProfileName": "Brian Carson \"Mobluesboy\"",
                "Text": "This record is ok, I love Big Joe and this is one of Roomful's great line-ups, but. I thought Joe was gettin to old when I first heard this record but I was talking with some of the Roomful guys and they confirmed my suspicions that Big Joe did'nt want to put his false teeth in, and you can sure tell. Look for the double CD which includes the Cleanhead Vinson record also. Worth having but there are better Big Joe Cd's, where he does have his teeth in.",
                "ReviewId": "3",
                "Date": "2008-04-10 00:00:00"
            },
            {
                "Score": "4.0",
                "Price": "52.88",
                "Helpfulness": "5/5",
                "UserId": "unknown",
                "HelpfulnessRatio": "1",
                "Title": "Rurouni Kenshin",
                "Summary": "Best Theme Collection not QUITE the Best",
                "ProductId": "B000058A7K",
                "ProfileName": "unknown",
                "Text": "I picked up this CD at an anime convention for ten bucks, and though it was worth the buy, it is far from holding all of the songs of the series that I love on it. However, this is a great place to start if you're just looking to get the main themes to the show.If you want more of Rurouni Kenshin's instrumental music I suggest you look somewhere else. There is also a great deal of J-POP centered around Kenshin, and if you can track those down, they're great fun to look into also.",
                "ReviewId": "4",
                "Date": "2004-07-11 00:00:00"
            },
            {
                "Score": "5.0",
                "Price": "52.88",
                "Helpfulness": "4/4",
                "UserId": "A3GFK7F5IUF60X",
                "HelpfulnessRatio": "1",
                "Title": "Rurouni Kenshin",
                "Summary": "RuroKen Theme Collection",
                "ProductId": "B000058A7K",
                "ProfileName": "Myra Schjelderup \"Ignolopi\"",
                "Text": "The Rurouni Kenshin anime has some very good ending and beginning songs. Though I heard some of them in English first, I'm not sure where to get them in English. Meanwhile, the ones in Japanese are just as fun (just a little harder to sing along to).If you import the CD onto iTunes (or whatever), the tracks will, for the most part, pop up with title and artist names in kana (pictographs). To make life easier, here is a list of the tracks as far as I've been able to get (so if I'm wrong, I'm sorry):Freckles (Sobakasu), by Judy and Mary. This song can seem really annoying at first, but give it a few chances, it's pretty cute.Tactics, by The Yellow Monkey. A great rock song, I really like the melody.Tears Know (Namida wa Shitte iru), Various Artists. A kind of slowish song, maybe a little annoying, but it's pretty.Heart of Sword - Before Dawn (Heart of Sword - Yoake Mae), by T.M.Revolution. This is a very good rock song, with a nice melody and very good harmonization (fun music).1/2, by Various Arists. This song probably will also sound annoying at first, but give it a few chances, because it's fun.It's Gonna Rain! by Bonnie Pink. A slower rock song, lots of fun to sing along even if you don't know the words, because 'ciao' is lots of fun to say....,1/3 True Feelings (1/3 no Junjou na Kanjou) by Siam Shade. I always think of it as 'my heart', because that's what he says a lot amidst the Japanese lyrics. It's a very pretty song, maybe a little sad.Everlasting Future (Towa no Mirai), Various Artists. I would like this song, except that I don't much care for the singer's voice at some points. I'm sure it doesn't annoy lots of people, but for me it keeps me from listening to it, even if I like the melody.Then there are 2 other songs which are over 7 minutes, and not very interesting in my opinion. Sorry I can't give any information on them.If you like this soundtrack (even if you don't), I also recommend Best of InuYasha, Samurai Deeper Kyo Vocal Album, and Naruto",
                "ReviewId": "5",
                "Date": "2006-03-13 00:00:00"
            },
            {
                "Score": "5.0",
                "Price": "23.68",
                "Helpfulness": "0/0",
                "UserId": "A32JO1FLE8KF05",
                "HelpfulnessRatio": "0",
                "Title": "Fame [Original London Cast Recording]",
                "Summary": "Michael Gore's awards",
                "ProductId": "B0000255AM",
                "ProfileName": "Anthony cruz \"pointer165\"",
                "Text": "they were a long time ago but I remember being very excited for his Oscar win for the song \"Fame\" and the music of the film along with Dean Pitchford...Now Michael is back with the musical \"Carrie\"..need to listen to it and a Golden Globe!Cheers,,TC(NYC)1981 Won Oscar Best Music, Original Scorefor",
                "ReviewId": "6",
                "Date": "2012-10-09 00:00:00"
            },
            {
                "Score": "4.0",
                "Price": "52.88",
                "Helpfulness": "4/4",
                "UserId": "A39FE38HDGEGG4",
                "HelpfulnessRatio": "1",
                "Title": "Rurouni Kenshin",
                "Summary": "Kenshin catchin' you.....",
                "ProductId": "B000058A7K",
                "ProfileName": "Annelise Lowe \"nyaaaaa\"",
                "Text": "This CD was the first anime CD that I ever recieved. And I must tell, you, it's been with me ever since. It's a great CD to take on trips and to listen to alone or with others. It's got songs for lots of different occaisons. Like &#34;Towa No Mirai&#34;, that's a slow-ish, rubato song, very sensual, too. The music rises and falls slowly and dramatically, and it captures the sorrow that Kenshin harbours in so terribly in his heart. But then there's track one, Sobakasu (the first opening, known in the American version as &#34;Freckled Face&#34;). That's one for jumping around. Hehe. It's all in Japanese, as is the rest of this CD. Really, my friends and I all get up and bounce around during this song, it's so upbeat, fun, and, well, bouncy. There's some really neat guitar stuff in that song. &#60;----There's some really neat guitar stuff on the entire CD, too. The last two song are longer than their predecessors, at about 8 minute. This album contains only ten songs from Kenshin, excluding some very nice ones, but, as this CD says, it has the Best Themes.",
                "ReviewId": "7",
                "Date": "2004-11-18 00:00:00"
            },
            {
                "Score": "5.0",
                "Price": "52.88",
                "Helpfulness": "3/3",
                "UserId": "A11DTN7MCCA4R4",
                "HelpfulnessRatio": "1",
                "Title": "Rurouni Kenshin",
                "Summary": "Definitely a great purchase!",
                "ProductId": "B000058A7K",
                "ProfileName": "\"rogomo\"",
                "Text": "For Kenshin fans, you already know why it'd be worth buying a cd of the opening and closing themes ... they're just all so great! And even if you haven't seen Rurouni Kenshin (you should), this cd provides a fantastic range of J-pop and J-rock selections. Very highly recommended.",
                "ReviewId": "8",
                "Date": "2001-08-13 00:00:00"
            },
            {
                "Score": "5.0",
                "Price": "16.17",
                "Helpfulness": "14/18",
                "UserId": "A2R2C5WPK89YUG",
                "HelpfulnessRatio": "0",
                "Title": "Haydn, Rossini & Mozart",
                "Summary": "WELL WORTH OWNING",
                "ProductId": "B0001Z4P6Y",
                "ProfileName": "R. Houck",
                "Text": "Really about a 4.7, but definitely closer to 5 than 4. Orchestra was very good although not a rival to Berlin. Photography was extremely crisp. My biggest gripe is that on several occasions during Beethoven's Emperor Piano Concerto the camera cut away from the pianist just as he was reaching a crescendo. Otherwise, direction and camera work were fine. I really couldn't list any flaws in the performance of Brahms' Symphony #3.In addition to the DVD-video, there is also an hour + of DVD-audio performances of Brahms Piano Concerto and waltzes.All together, a good value given the total amount of music and worth a spot in your collection.",
                "ReviewId": "9",
                "Date": "2005-08-03 00:00:00"
            },
            {
                "Score": "5.0",
                "Price": "52.88",
                "Helpfulness": "1/1",
                "UserId": "A3NIQK6ZLYEP1L",
                "HelpfulnessRatio": "1",
                "Title": "Rurouni Kenshin",
                "Summary": "Memories...",
                "ProductId": "B000058A7K",
                "ProfileName": "Michael Valdivielso",
                "Text": "Being a fan of Rurouni Kenshin, just having finished the TV series and looking forward to the movies and OVA, this CD was a must. I love Tactics and One Half and already know the lyrics from watching the episodes! I listen to the CD while looking at manga and artbooks.It was a must for my music library. A lot of time and money went into the making of these soundtracks and it was worth it! The CD would make a great gift for kids - upbeat and fun!",
                "ReviewId": "10",
                "Date": "2006-05-13 00:00:00"
            },
            {
                "Score": "4.0",
                "Price": "16.17",
                "Helpfulness": "4/4",
                "UserId": "APBU0ZTWST14T",
                "HelpfulnessRatio": "1",
                "Title": "Haydn, Rossini & Mozart",
                "Summary": "Rare Historic Footage of Cliburn Gold Medalist pianist Steven De Groote",
                "ProductId": "B0001Z4P6Y",
                "ProfileName": "Thomas Ramey",
                "Text": "This DVD has rare footage of Steven De Groote (1977 Van Cliburn competition Gold Medalist) playing Chopin Piano Concerto No. 2 in 1983 when he was 30 years old. De Groote died in 1989 at age 36. While visiting relatives in South Africa, he was hospitalized for pneumonia and influenza, eventual cause of death was inflammation of the liver. We lost one of the most promising pianists of his generation.The program on the DVD is:Schumann",
                "ReviewId": "11",
                "Date": "2010-02-11 00:00:00"
            }
        ]
    }

    // static MusicList = this.props.reviews;

    onSearch = (event) => {
        this.setState({ searchedValue: event.target.value });
        console.log(event.target.value);
    }
   

    
    render() {
        console.log(this.props.MusicList);
        console.log(this.state.searchedValue);

        const filteredItems = this.props.MusicList.filter((item) => item.Title != null && item.Title.includes(this.state.searchedValue));


        return (
            <div className = "searchTable" style = {{ display: "flex", flexWrap: "wrap" }}>
                <div className="form-group">
                    <input className="form-input" type="text" placeholder="search" onChange={this.onSearch} value={this.state.searchedValue} />
                </div>
                <Table striped bordered responsive id = "musicTable">
                    <thead>
                        <MusicTableHeader/>
                    </thead>
                    <tbody>
                        {filteredItems.map((Music, i) => {
                            return <MusicTableRow Music = {Music} key = {i} />
                        })}
                    </tbody>
                </Table>
            </div>
        );
    }
}


export default MusicTable