import React from 'react';
import '../styles/Select.scss';

const Select = props => {
    return (
        <div className="form-group">
            <select name={props.name} value={props.value} onChange={props.onChange}>
                {console.log(props.name)}
                <option value="" disabled>
                    {props.placeholder}
                </option>
                {props.options.map((option, index) => {
                    return (
                        <option key={index} value={option} label={option}>
                            {option}
                        </option>
                    )
                })}
            </select>
        </div>
    )
}

export default Select;