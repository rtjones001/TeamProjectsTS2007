import React, { Component } from 'react'
import { BarChart } from 'react-d3-components'

var data = {
    label: 'Music Data',
    values: [
        {"x": "If I Ain't Got You", "y": 150 },
        {"x": "Let It Go", "y": 120},
        {"x": "My Shot", "y": 80},
        {"x": "Friday", "y": 77},
        {"x": "Coconut Song", "y": 70},
        {"x": "Yeah!", "y": 53},
        {"x": "Hot N Cold", "y": 25},
        {"x": "Hips Don't Lie", "y": 24}
    ]
};

var sort = null; // d3.ascending, d3.descending, func(a,b) { return a - b; }, etc...

var tooltipBar = function(label, y0, y){
    return ("label: "+label+", y0: "+y0+", y: "+y);
}


class MusicBarChart extends Component {
    state = { searchedValue: '' };

    onSearch = (event) => {
        this.setState({ searchedValue: event.target.value });
        
        console.log(event.target.value);
    }
    render(){
        const filteredItems = this.props.data.values.filter((item) => item.Title.includes(this.state.searchedValue));
        return (
            <div className="barchart">
                <h2>{data.label}</h2>
                <BarChart
                    data={filteredItems}
                    width={800}
                    height={400}
                    margin={{top: 50, bottom: 50, left: 100, right: 100}}
                    sort={sort}
                    tooltipHtml={tooltipBar}
                />
                <style>{`
                g.x.axis text {
                    font-size: 10px;
                    transform-origin: 25px 50px;
                    transform: rotate(-25deg);
                }

                .tooltip {
                    background-color: rgba(160, 160, 160, 0.7);
                    opacity: 1;
                    border-radius: 10px;
                    padding: 5px;
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                }
                `}</style>
            </div>
        )
    }
}

export default MusicBarChart
