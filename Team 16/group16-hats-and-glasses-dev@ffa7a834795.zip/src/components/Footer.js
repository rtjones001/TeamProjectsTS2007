import React from 'react';
import '../styles/Footer.scss';

function Footer() {

    return (

        <footer className="footer-container">

            <div className="container">
                <p>&#169; Liberty Mutual Insurance | All Rights Reserved</p>
                <div className="icon-container">
                    <a href="https://www.facebook.com/libertymutual/" target="_blank"  rel="noopener noreferrer" className="fa fa-facebook"><span></span></a>
                    <a href="https://twitter.com/LibertyMutual" target="_blank" rel="noopener noreferrer" className="fa fa-twitter"><span></span></a>
                    <a href="https://www.instagram.com/libertymutual/?hl=en" target="_blank" rel="noopener noreferrer" className="fa fa-instagram"><span></span></a>
                </div>
            </div>

        </footer>

    )

}

export default Footer;