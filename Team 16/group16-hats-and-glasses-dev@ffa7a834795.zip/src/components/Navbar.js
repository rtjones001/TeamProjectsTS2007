import React from "react";
import { NavLink } from 'react-router-dom';
import '../styles/Navbar.scss';
 
function NavBar() {
    return (
        <div className="nav_list"  style = {{ backgroundColor : "#002663" }} >
            <h1><NavLink to = '/' style = {{ color : "#f6d680" }}>Amazon Music Reviews</NavLink></h1>
            <ul>
                <li><NavLink to='/'>Home</NavLink></li>
                <li><NavLink to='/detailedcharts'>Detailed Charts</NavLink></li>
                <li><NavLink to='/about'>About</NavLink></li>
            </ul>
        </div>
    );
}
 
export default NavBar