import React from 'react';
import '../styles/Button.scss';

const Button = props => {

    return (
        <div>
            <button type={props.type} onClick={props.action}>
                {props.title}
            </button>
        </div>
    )

}

export default Button;