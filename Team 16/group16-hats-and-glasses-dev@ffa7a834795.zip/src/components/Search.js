import React from 'react';
import { MDBDataTable } from 'mdbreact';
import '../css/MusicTable.css'

const SearchTable = () => {
    const data = {
      columns: [
        {
          label: 'ProductID',
          field: 'productID',
          sort: 'asc',
          width: 150
        },
        {
          label: 'Title',
          field: 'Title',
          sort: 'asc',
          width: 150
        },
        {
          label: 'Price',
          field: 'Price',
          sort: 'asc',
          width: 150
        },
        {
          label: 'ProfileName',
          field: 'ProfileName',
          sort: 'asc',
          width: 150
        },
        {
          label: 'Helpfulness',
          field: 'Helpfulness',
          sort: 'asc',
          width: 150
        },
        {
          label: 'Score',
          field: 'Score',
          sort: 'asc',
          width: 150
        },
        {
          label: 'ReviewTime',
          field: 'ReviewTime',
          sort: 'asc',
          width: 150
        },
        {
          label: 'Summary',
          field: 'Summary',
          sort: 'asc',
          width: 150
        },
        {
          label: 'Review',
          field: 'Review',
          sort: 'asc',
          width: 150
        }
      ],
      rows: [
       {
            "productID": '1',
            "Title": "a",
            "Price": "11",
            "ProfileName": ".",
            "Helpfulness": "3/3",
            "Score": "5",
            "ReviewTime": "11",
            "Summary":"asd",
            "Review":"asd"
        },
        {
            "productID": '2',
            "Title": "b",
            "Price": "12",
            "ProfileName": ".",
            "Helpfulness": "2/2",
            "Score": "4",
            "ReviewTime": "11",
            "Summary":"asd",
            "Review":"asdf"
        },
        {
            "productID": '3',
            "Title": "c",
            "Price": "13",
            "ProfileName": ".",
            "Helpfulness": "1/1",
            "Score": "3",
            "ReviewTime": "11",
            "Summary":"asd",
            "Review":"adfg"
        },
        {
            "productID": '4',
            "Title": "d",
            "Price": "14",
            "ProfileName": ".",
            "Helpfulness": "0/0",
            "Score": "2",
            "ReviewTime": "11",
            "Summary":"asd",
            "Review":"adsfgh"
        },
        {
          "productID": '5',
          "Title": "a",
          "Price": "11",
          "ProfileName": ".",
          "Helpfulness": "3/3",
          "Score": "5",
          "ReviewTime": "11",
          "Summary":"asd",
          "Review":"asd"
        },
        {
          "productID": '6',
          "Title": "a",
          "Price": "11",
          "ProfileName": ".",
          "Helpfulness": "3/3",
          "Score": "5",
          "ReviewTime": "11",
          "Summary":"asd",
          "Review":"asd"
      },
        {
          "productID": '7',
          "Title": "a",
          "Price": "11",
          "ProfileName": ".",
          "Helpfulness": "3/3",
          "Score": "5",
          "ReviewTime": "11",
          "Summary":"asd",
          "Review":"asd"
        },
        {
          "productID": '8',
          "Title": "a",
          "Price": "11",
          "ProfileName": ".",
          "Helpfulness": "3/3",
          "Score": "5",
          "ReviewTime": "11",
          "Summary":"asd",
          "Review":"asd"
        },
  {
    "productID": '9',
    "Title": "a",
    "Price": "11",
    "ProfileName": ".",
    "Helpfulness": "3/3",
    "Score": "5",
    "ReviewTime": "11",
    "Summary":"asd",
    "Review":"asd"
},
{
  "productID": '10',
  "Title": "a",
  "Price": "11",
  "ProfileName": ".",
  "Helpfulness": "3/3",
  "Score": "5",
  "ReviewTime": "11",
  "Summary":"asd",
  "Review":"asd"
},
{
  "productID": '11',
  "Title": "a",
  "Price": "11",
  "ProfileName": ".",
  "Helpfulness": "3/3",
  "Score": "5",
  "ReviewTime": "11",
  "Summary":"asd",
  "Review":"asd"
},
{
  "productID": '12',
  "Title": "a",
  "Price": "11",
  "ProfileName": ".",
  "Helpfulness": "3/3",
  "Score": "5",
  "ReviewTime": "11",
  "Summary":"asd",
  "Review":"asd"
},
{
  "productID": '13',
  "Title": "a",
  "Price": "11",
  "ProfileName": ".",
  "Helpfulness": "3/3",
  "Score": "5",
  "ReviewTime": "11",
  "Summary":"asd",
  "Review":"asd"
},
        {
          "productID": '14',
          "Title": "a",
          "Price": "11",
          "ProfileName": ".",
          "Helpfulness": "3/3",
          "Score": "5",
          "ReviewTime": "11",
          "Summary":"asd",
          "Review":"asd"
        }
      ]
    };
   
    
    return (
      <div className = "searchTable">
          <MDBDataTable striped bordered small data={ data } sorting={true}/>
      </div>
    );
    
}


export default SearchTable