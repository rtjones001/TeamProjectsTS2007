import React, { Component } from "react";
import { Container, Row, Col } from 'react-bootstrap'
import Music from "./MusicCard";
import 'bootstrap/dist/css/bootstrap.min.css';
 
class MusicCardTable extends Component {

  constructor(props) {
    super(props);
  }

  static defaultProps = {
      top: [
          {
              "numOfReviews" : 500,
              "productId": 1,
              "price": "41.33",
              "title": "a",
              "averageScore": "5"
            },
            {
              "numOfReviews" : 500,
              "productId": 1,
              "price": "41.33",
              "title": "a",
              "averageScore": "5"
            },
            {
              "numOfReviews" : 500,
              "productId": 1,
              "price": "41.33",
              "title": "a",
              "averageScore": "5"
            },
            {
              "numOfReviews" : 500,
              "productId": 1,
              "price": "41.33",
              "title": "a",
              "averageScore": "5"
            },
            {
              "numOfReviews" : 500,
              "productId": 1,
              "price": "41.33",
              "title": "a",
              "averageScore": "5"
            },
            {
              "numOfReviews" : 500,
              "productId": 1,
              "price": "41.33",
              "title": "a",
              "averageScore": "5"
            },
            {
              "numOfReviews" : 500,
              "productId": 1,
              "price": "41.33",
              "title": "a",
              "averageScore": "5"
            },
            {
              "numOfReviews" : 500,
              "productId": 1,
              "price": "41.33",
              "title": "a",
              "averageScore": "5"
            },
            {
              "numOfReviews" : 500,
              "productId": 1,
              "price": "41.33",
              "title": "a",
              "averageScore": "5"
            },
            {
              "numOfReviews" : 500,
              "productId": 1,
              "price": "41.33",
              "title": "a",
              "averageScore": "5"
            }
      ]

      // musicData: this.props.top

  }

  render() {
    // let { submission} = this.state;
    console.log(this.props.top);
    return (
        <Container fluid = "md" style={{ justifyCenter: "center", display: "flex", flexWrap: "wrap" }}>
          <Row style = {{ height : "15em",  marginTop: "2em", display: "flex", flexWrap: "wrap" }}>
              {this.props.top.map((music, i) =>{
                      
                  return(
                  <Col sm = '3' style={{ maxWidth: "20%" }} >
                      <Music key = {i} music = { music }/>
                  </Col>

                  
                  );
              })}
          </Row>
        </Container>
      
    );
  }
}
 
export default MusicCardTable;