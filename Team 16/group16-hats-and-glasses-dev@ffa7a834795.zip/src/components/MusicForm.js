import React, { Component } from 'react';
import Input from './Input';
import Select from './Select';
import Button from './Button';
import '../styles/MusicForm.scss';
import { Formik } from 'formik'
import Container from 'react-bootstrap/Container';
import Alert from 'react-bootstrap/Alert';
import Row from 'react-bootstrap/Row';
import MusicLineChart from './MusicLineChart';
import MusicBarChart from './MusicBarChart';

const REQUEST_URL = "http://group16-hats-and-glasses-backend-development.us-east-1.np.paas.lmig.com";

class MusicForm extends Component {

    state = {
        submission: {
            option: "",
            productParam: ""
        },
        options: ["Product Name", "Product ID"],
        placeholder: "",
        event: {
            scores: {},
            dates: {}
        }
    }

    constructor(props) {
        super(props);
        this.handleChange = this.handleChange.bind(this);
        this.handleClearForm = this.handleClearForm.bind(this);
        this.handleSubmitForm = this.handleSubmitForm.bind(this);
    }

    handleChange(event) {

        let name = event.target.name;
        let value = event.target.value;
        let type = event.target.type;

        if (type === "select-one") {
            if (value === "Product Name") {
                this.setState((prev) => {
                    return {
                        submission: { ...prev.submission },
                        placeholder: "Enter a product name..."
                    }
                })
            } else if (value === "Product ID") {
                this.setState((prev) => {
                    return {
                        submission: { ...prev.submission },
                        placeholder: "Enter a product ID..."
                    }
                })
            }
        }

        this.setState((prev) => {
            return {
                submission: { ...prev.submission, [name]: value }
            }
        }, () => console.log("Changed " + name + " to " + this.state.submission[name]));

    }

    handleClearForm(values) {
        this.setState({
          submission: {
            option: "",
            productParam: ""
          },
          placeholder: ""
        });
        console.log("Form cleared");
      }

    handleSubmitForm(values, { setSubmitting }) {

        const submission = values;
        alert(JSON.stringify(submission, null, 2));
        console.log("Submitted submission: " + JSON.stringify(submission));
        setSubmitting(false);

        if (this.state.submission.option === "Product Name") {
            fetch(REQUEST_URL + '/api/music/productName/' + this.state.submission.productParam)
                .then(data => data.json())
                .then(data => this.setState({
                    event: data
                }));
        } else if (this.state.option === "Product ID") {
            fetch(REQUEST_URL + '/api/music/productId/' + this.state.submission.productParam)
                .then(data => data.json())
                .then(data => this.setState({
                    event: data
                }));
        }

    }

    handleValidateForm(values) {

        let errors = {};
        let option = values.option;
        let productParam = values.productParam;

        console.log(option);
        console.log(productParam);

        if (!productParam.length > 0 && option === "Product Name") {
            errors.productParam = "A product name is required.";
        } else if (!productParam.length > 0 && option === "Product ID") {
            errors.productParam = "A product ID is required.";
        } else if(!productParam.length > 0) {
            errors.productParam = "A product name or ID is required.";
        }

        if (!values.option.length > 0) {
            errors.option = "An option is required."
        }

        return errors;

    }

    render() {

        let { submission, options, placeholder } = this.state;

        return (
            <Container fluid>
                <Formik 
                    enableReinitialize={true}
                    initialValues={submission}
                    validate={this.handleValidateForm}
                    onReset={this.handleClearForm}
                    onSubmit={this.handleSubmitForm}
                >

                    { formikProps => {
                        let {
                            values,
                            errors,
                            touched,
                            handleChange,
                            handleReset,
                            handleSubmit
                          } = formikProps;
                    
                        return (
                            <form className="form-container">

                                <Row className="row-flex">
                                    <Select 
                                        title={"Options: "} 
                                        name={"option"}
                                        value={values.option} 
                                        options={options} 
                                        placeholder={"Filter by product name or ID..."}
                                        onChange={handleChange} />

                                    <Input
                                        title={submission.option}
                                        type={"text"}
                                        name={"productParam"}
                                        value={values.productParam}
                                        placeholder={placeholder}
                                        onChange={handleChange} />

                                    <Button type="submit" action={handleSubmit} title={"Submit"} />
                                    <Button type="reset" action={handleReset} title={"Clear"} />
                                </Row>

                                <Row className="row-flex-alerts">
                                    <Alert show={!errors.option === ""} variant={"danger"}>
                                        {errors.option && touched.option && errors.option}
                                    </Alert>

                                    <Alert show={!errors.productParam === ""} variant={"danger"}>
                                        {errors.productParam && touched.productParam && errors.productParam}
                                    </Alert>
                                </Row>

                            </form>

                        );
                    }}
                </Formik>

                <div className="flex">
                    <MusicBarChart event={this.state.event} />
                    <MusicLineChart event={this.state.event} />
                </div>

            </Container>
        )

    }
}

export default MusicForm;