# group16-hats-and-glasses

<!-- shields -->

[![Build Status](https://shields.lmig.com/bamboo/tests/TC/GHAG.svg?style=flat-square)](https://forge.lmig.com/builds/browse/TC-GHAG)<!-- /shields -->

---

## Project Structure

**[/deployment/](./deployment/)** - contains Cloud Foundry manifest files for each of your deployment environments
