# group16-hats-and-glasses-backend

<!-- shields -->

[![Build Status](https://shields.lmig.com/bamboo/tests/TC/GHAGB.svg?style=flat-square)](https://forge.lmig.com/builds/browse/TC-GHAGB)<!-- /shields -->

---

## Project Structure

**[/src/main/deployment/](./src/main/deployment/)** - contains Cloud Foundry manifest files for each of your deployment environments
