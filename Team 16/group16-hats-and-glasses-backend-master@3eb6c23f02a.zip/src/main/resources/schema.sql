CREATE TABLE Product (
	AmazonProductId VARCHAR(20) PRIMARY KEY,
    ProductPrice DECIMAL(10,2),
    ProductTitle VARCHAR(300)
);

CREATE TABLE Score  (
    ScoreId INT PRIMARY KEY AUTO_INCREMENT,
    ScoreValue DECIMAL(2,1) NOT NULL
);

CREATE TABLE User (
	UserId INT PRIMARY KEY AUTO_INCREMENT,
	AmazonUserId VARCHAR(40) NOT NULL
);

CREATE TABLE ProfileName (
	ProfileNameId INT PRIMARY KEY AUTO_INCREMENT,
	ProfileNameValue VARCHAR(150)
);

CREATE TABLE Review (
    ReviewId INT PRIMARY KEY AUTO_INCREMENT,
    UserId INT NOT NULL,
    ProfileNameId INT NOT NULL,
    ProductId VARCHAR(20) NOT NULL,
    ScoreId INT NOT NULL,
    HelpfulVotes INT NOT NULL,
    ReviewDate DATETIME NOT NULL,
    ReviewSummary VARCHAR(400),
    ReviewText TEXT,
    TotalVotes INT NOT NULL,
    CONSTRAINT fk_Review_UserId
    	FOREIGN KEY (UserId)
    	REFERENCES User(UserId),
    CONSTRAINT fk_Review_ProfileNameId
    	FOREIGN KEY (ProfileNameId)
    	REFERENCES ProfileName(ProfileNameId),
    CONSTRAINT fk_Review_AmazonProductId
    	FOREIGN KEY (ProductId)
    	REFERENCES Product(AmazonProductId),
    CONSTRAINT fk_Review_ScoreId
    	FOREIGN KEY (ScoreId)
    	REFERENCES Score(ScoreId)
);