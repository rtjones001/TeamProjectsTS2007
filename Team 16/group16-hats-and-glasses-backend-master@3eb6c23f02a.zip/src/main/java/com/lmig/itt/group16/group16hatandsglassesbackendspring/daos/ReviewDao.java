package com.lmig.itt.group16.group16hatandsglassesbackendspring.daos;

import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.Product;
import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.Review;
import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.Score;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Map;

public interface ReviewDao {

    // API Endpoints
    List<Map<String,String>> getAllReviews(int numberOfRecords, int offset);
    Map<Float, Integer> getReviewScoreCount();
    Map<String, Map<String, String>>  getScoresAndDatesByProductName(String productName) throws JSONException;
    Map<String, Map<String, String>>  getScoresAndDatesByProductId(String productId) throws JSONException;
    Map<String, String> getReviewStats() throws JSONException;

    Map<String, String> getReviewStatsByProductId(String productId, String reviewCount)  throws JSONException;
    List<Map<String, String>> getMostReviewedProducts();
    Integer getTotalReviewCount();

    // Create, should check if User exists before adding
    @Transactional
    Review addReview (Review review);
}
