package com.lmig.itt.group16.group16hatandsglassesbackendspring.daos;

import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.Product;
import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.Score;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.math.BigDecimal;

@Repository
public class ScoreDaoDB implements ScoreDao {

    @Autowired
    JdbcTemplate jdbc;

    public static final class ScoreMapper implements RowMapper<Score> {

        @Override
        public Score mapRow(ResultSet rs, int index) throws SQLException {
            Score score = new Score();
            score.setScoreId(rs.getInt("scoreId"));
            score.setScoreValue(rs.getBigDecimal("scoreValue"));
            return score;
        }
    }

    @Override
    public Integer getScoreIdByScoreValue(BigDecimal scoreValue) {
        Score score = getScoreByScoreValue(scoreValue);
        return score.getScoreId();
    }

    @Override
    public Score getScoreByScoreValue(BigDecimal scoreValue) {
        try {
            final String SELECT_SCORE_BY_VALUE = "SELECT * FROM score WHERE scoreValue = ? LIMIT 1";
            return jdbc.queryForObject(SELECT_SCORE_BY_VALUE, new ScoreMapper(), scoreValue);
        } catch(DataAccessException ex) {
            return null;
        }
    }

    @Override
    public Score getScoreByScoreId(Integer scoreId) {
        try {
            final String SELECT_SCORE_BY_ID = "SELECT * FROM score WHERE scoreId = ? LIMIT 1";
            return jdbc.queryForObject(SELECT_SCORE_BY_ID, new ScoreMapper(), scoreId);
        } catch(DataAccessException ex) {
            return null;
        }
    }

    @Override
    @Transactional
    public Score addScore (Score score) {
        Score testScore = getScoreByScoreValue(score.getScoreValue());
        if (testScore == null) {
            final String INSERT_SCORE = "INSERT INTO Score(ScoreValue) VALUES(?)";
            jdbc.update(INSERT_SCORE,
                    score.getScoreValue());

            int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
            score.setScoreId(newId);
            return score;
        }
        return testScore;
    }
}
