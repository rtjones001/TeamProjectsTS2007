package com.lmig.itt.group16.group16hatandsglassesbackendspring.daos;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.Product;
import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.Review;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

@Repository
public class ReviewDaoDB implements ReviewDao {

    @Autowired
    JdbcTemplate jdbc;

    @Autowired
    ProductDaoDB productDaoDB;

    public static final class ReviewMapper implements RowMapper<Map<String,String>> {

        @Override
        public Map<String,String> mapRow(ResultSet rs, int index) throws SQLException {
            Map<String,String> review = new HashMap();
            review.put("ReviewId", rs.getString("ReviewId"));
            review.put("ProductId", rs.getString("ProductId"));
            review.put("Title", rs.getString("Title"));
            review.put("Price", rs.getString("Price"));
            review.put("UserId", rs.getString("UserId"));
            review.put("ProfileName", rs.getString("ProfileName"));
            review.put("Helpfulness", rs.getString("Helpfulness"));
            review.put("HelpfulnessRatio", rs.getString("HelpfulnessRatio"));
            review.put("Score", rs.getString("Score"));
            review.put("Date", rs.getString("Date"));
            review.put("Summary", rs.getString("Summary"));
            review.put("Text", rs.getString("Text"));
            return review;
        }
    }

    @Override
    public List<Map<String,String>> getAllReviews(int numberOfRecords, int offset) {
        final String SELECT_ALL_REVIEWS =
                        "SELECT " +
                            "Review.ReviewId, " +
                            "Product.AmazonProductId AS ProductId, " +
                            "Product.ProductTitle AS Title, " +
                            "Product.ProductPrice AS Price, " +
                            "User.AmazonUserId AS UserId, " +
                            "ProfileName.ProfileNameValue AS ProfileName, " +
                            "CONCAT(Review.HelpfulVotes, '/',Review.TotalVotes) AS Helpfulness, " +
                            "(CASE WHEN Review.TotalVotes > 0 " +
                            "THEN (Review.HelpfulVotes / Review.TotalVotes) " +
                            "ELSE 0 " +
                            "END) AS HelpfulnessRatio," +
                            "Score.ScoreValue AS Score," +
                            "Review.ReviewDate AS Date," +
                            "Review.ReviewSummary AS Summary," +
                            "Review.ReviewText AS Text " +
                        "FROM review " +
                        "JOIN User on Review.UserId = User.UserId " +
                        "JOIN Product on Review.ProductId = Product.AmazonProductId " +
                        "JOIN ProfileName on Review.ProfileNameId = ProfileName.ProfileNameId " +
                        "JOIN Score on Review.ScoreId = Score.ScoreId " +
                        "ORDER BY reviewId " +
                        "LIMIT ? " +
                        "OFFSET ? ";
        return jdbc.query(SELECT_ALL_REVIEWS, new ReviewMapper(), numberOfRecords, offset);
    }

    //Pie chart on home page
    //Count of how many reviews of each scoreId (1, 2, 3, 4, 5)
    //Return number of reviews per score value
    @Override
    public Map<Float, Integer> getReviewScoreCount() {
        return jdbc.query("SELECT score.scoreValue, COUNT(*) AS scoreCOUNT " +
                "FROM score JOIN review ON score.scoreId = review.scoreId " +
                "GROUP BY score.scoreValue", (ResultSet rs) -> {
            Map<Float, Integer> results = new HashMap<>();
            while (rs.next()) {
                results.put(rs.getFloat("scoreValue"), rs.getInt("scoreCount"));
            }
            return results;
        });
    }

    //Get scores from Score and Dates from Review by Product Name
    @Override
    public Map<String, Map<String, String>>  getScoresAndDatesByProductName(String productName) throws JSONException {
        final String GET_PRODUCT_SCORES =
                "SELECT  " +
                    "Score.ScoreValue,  " +
                    "COUNT(*) AS ScoreCount " +
                "FROM Score  " +
                "JOIN Review ON Score.ScoreId = Review.ScoreId  " +
                "JOIN Product ON Review.ProductId = Product.AmazonProductId  " +
                "WHERE Product.ProductTitle = ? " +
                "GROUP BY Score.ScoreValue  " ;
        Map<String, String> score = jdbc.query(GET_PRODUCT_SCORES, ((ResultSet rs) -> {
            Map<String, String> results = new HashMap<>();
            while (rs.next()) {
                results.put(rs.getString("scoreValue"), rs.getString("scoreCount"));
            }
            return results;
        }), productName);

        final String SELECT_REVIEW_DATES = "SELECT SUBSTRING(reviewDate, 1, 7) AS dateOfReview, " +
                "COUNT(*) AS reviewCount FROM review "+
                "JOIN product ON review.productId = product.amazonProductId  " +
                "WHERE product.productTitle = ? " +
                "GROUP BY dateOfReview ORDER BY reviewCount";
        Map<String, String> reviewDates = jdbc.query(SELECT_REVIEW_DATES, ((ResultSet rs) -> {
            Map<String, String> results = new HashMap<>();
            while (rs.next()) {
                results.put(rs.getString("dateOfReview"), rs.getString("reviewCount"));
            }
            return results;
        }), productName);
        Map<String, Map<String, String>> product = new HashMap<>();
        product.put("scores", score);
        product.put("dates", reviewDates);

        return product;
    }

    @Override
    public Map<String, Map<String, String>>  getScoresAndDatesByProductId(String productId) throws JSONException {
        final String GET_PRODUCT_SCORES = "SELECT score.scoreValue, COUNT(*) AS scoreCOUNT " +
                "FROM score " +
                "JOIN review ON score.scoreId = review.scoreId " +
                "WHERE review.productId = ? " +
                "GROUP BY score.scoreValue";
        Map<String, String> score = jdbc.query(GET_PRODUCT_SCORES, ((ResultSet rs) -> {
            Map<String, String> results = new HashMap<>();
            while (rs.next()) {
                results.put(rs.getString("scoreValue"), rs.getString("scoreCount"));
            }
            return results;
        }), productId);

        final String SELECT_REVIEW_DATES = "SELECT SUBSTRING(reviewDate, 1, 7) AS dateOfReview, " +
                "COUNT(*) AS reviewCount FROM review WHERE review.productId = ?" +
                "GROUP BY reviewDate ORDER BY reviewCount";
        Map<String, String> reviewDates = jdbc.query(SELECT_REVIEW_DATES, ((ResultSet rs) -> {
            Map<String, String> results = new HashMap<>();
            while (rs.next()) {
                results.put(rs.getString("dateOfReview"), rs.getString("reviewCount"));
            }
            return results;
        }), productId);
        Map<String, Map<String, String>> product = new HashMap<>();
        product.put("scores", score);
        product.put("dates", reviewDates);

        return product;
    }

    //Helper method to convert score and date to json for getScoresAndDatesByProductId() and
    // getScoresAndDatesByProductName()
    public JSONObject convertScoreAndDateToJson(Map<Float, Integer> scores, Map<String, Integer> reviewDates) throws JSONException {
        ObjectMapper scoreMapper = new ObjectMapper();
        String mappedScores = null;
        try {
            mappedScores = scoreMapper.writeValueAsString(scores);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        ObjectMapper dateMapper = new ObjectMapper();
        String mappedDates = null;
        try {
            mappedDates = dateMapper.writeValueAsString(reviewDates);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }

        JSONObject product = new JSONObject();
        product.put("scores", mappedScores);
        product.put("dates", mappedDates);

        return product;
    }

    //getTotalReviewCount(), getTotalProductCount(), and getMostReviewedProducts()
    // are all used in getReviewStats()
    @Override
    public Map<String, String> getReviewStats() throws JSONException {
        Map<String, String> reviewStats = new HashMap<>();
        reviewStats.put("totalReviews", getTotalReviewCount().toString());
        reviewStats.put("totalProducts", productDaoDB.getTotalProductCount().toString());

        return reviewStats;
    }

    //Get the review stats for one product by ProductId
    //This it will be used for getReviewStats()
    @Override
    public Map<String, String> getReviewStatsByProductId(String productId, String reviewCount) {
        Product product = productDaoDB.getProductByProductId(productId);
        final String SELECT_SCORE_VALUE_AVG = "SELECT AVG(score.scoreValue) FROM score " +
                "JOIN review ON score.scoreId = review.scoreId WHERE review.productId = ?";
        Float avg = jdbc.queryForObject(SELECT_SCORE_VALUE_AVG, Float.class, productId);
//        final String SELECT_SCORE_VALUE_COUNT ="SELECT score.scoreValue, " +
//                "COUNT(*) AS scoreCount FROM score JOIN review ON score.scoreId = review.scoreId " +
//                "GROUP BY score.scoreValue WHERE review.productId = ?";
//        Integer numOfReviews = jdbc.queryForObject(SELECT_SCORE_VALUE_COUNT, Integer.class, productId);

        Map<String, String> reviewStats = new HashMap<>();
        String price = product.getProductPrice() == null ? "unknown" : product.getProductPrice().toString();
        String title = product.getProductTitle() == null ? "unknown" : product.getProductTitle().toString();;

        reviewStats.put("productId", productId);
        reviewStats.put("title", title);
        reviewStats.put("price", price);
        reviewStats.put("averageScore", avg.toString());
        reviewStats.put("numOfReviews", reviewCount);
        return reviewStats;
    }

    //Use most reviewed products for getReviewStats()
    @Override
    public List<Map<String, String>> getMostReviewedProducts() {
        final String SELECT_MOST_REVIEWED = "SELECT productId, COUNT(productId) AS reviewCount FROM review " +
                "GROUP BY productId ORDER BY reviewCount desc LIMIT 10";
        Map<String, String> products = jdbc.query(SELECT_MOST_REVIEWED, ((ResultSet rs) -> {
            Map<String, String> results = new HashMap<>();
            while (rs.next()) {
                results.put(rs.getString("productId"), rs.getString("reviewCount"));
            }
            return results;
        }));

        List<Map<String, String>> productStats = new ArrayList<>();
        for ( Map.Entry<String,String> product : products.entrySet()) {
            productStats.add(getReviewStatsByProductId(product.getKey(), product.getValue()));
        }
        return productStats;
    }

    //Use total count Review for getReviewStats()
    @Override
    public Integer getTotalReviewCount() {
        final String COUNT_ALL_REVIEWS = "SELECT COUNT(*) FROM review";
        return jdbc.queryForObject(COUNT_ALL_REVIEWS, Integer.class);
    }

    @Override
    @Transactional
    public Review addReview(Review review) {
        final String INSERT_REVIEW = "INSERT INTO review(userId, profileNameId, productId, " +
                "scoreId, helpfulVotes, totalVotes, reviewDate, reviewSummary, reviewText) " +
                "VALUES(?,?,?,?,?,?,?,?,?)";
        jdbc.update(INSERT_REVIEW,
                review.getUserId(),
                review.getProfileNameId(),
                review.getProductId(),
                review.getScoreId(),
                review.getHelpfulVotes(),
                review.getTotalVotes(),
                review.getReviewDate(),
                review.getReviewSummary(),
                review.getReviewText());

        int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
        review.setReviewId(newId);
        return review;
    }
}

