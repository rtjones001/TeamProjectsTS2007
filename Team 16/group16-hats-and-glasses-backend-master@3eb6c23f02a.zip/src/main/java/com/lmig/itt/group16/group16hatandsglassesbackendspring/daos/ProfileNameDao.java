package com.lmig.itt.group16.group16hatandsglassesbackendspring.daos;

import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.ProfileName;
import org.springframework.transaction.annotation.Transactional;

public interface ProfileNameDao {

    Integer getProfileNameIdByProfileNameValue(String profileNameValue);
    ProfileName getProfileNameByProfileNameValue(String profileNameValue);
    ProfileName getProfileNameByProfileNameId(Integer profileNameId);

    // Create, should check if ProfileName exists before adding
    @Transactional
    ProfileName addProfileName (ProfileName profileName);
}
