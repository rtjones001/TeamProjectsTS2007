package com.lmig.itt.group16.group16hatandsglassesbackendspring.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProfileName {
    @NonNull Integer profileNameId;
    String profileNameValue;
}
