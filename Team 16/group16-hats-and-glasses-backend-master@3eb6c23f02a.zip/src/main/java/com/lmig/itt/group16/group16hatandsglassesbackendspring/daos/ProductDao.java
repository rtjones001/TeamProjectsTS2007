package com.lmig.itt.group16.group16hatandsglassesbackendspring.daos;

import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.Product;
import org.springframework.transaction.annotation.Transactional;

public interface ProductDao {

    String getProductIdByProductTitle(String productTitle);
    Product getProductByProductTitle(String productTitle);
    Product getProductByProductId(String productId);
    Integer getTotalProductCount();

    // Create, should check if Product exists before adding
    @Transactional
    Product addProduct (Product product);
}
