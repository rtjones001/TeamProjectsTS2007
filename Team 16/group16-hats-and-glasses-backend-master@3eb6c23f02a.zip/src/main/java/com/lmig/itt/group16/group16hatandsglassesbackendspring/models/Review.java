package com.lmig.itt.group16.group16hatandsglassesbackendspring.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Review {
    @NonNull Integer reviewId;
    @NonNull Integer userId;
    @NonNull Integer profileNameId;
    @NonNull String productId;
    @NonNull Integer scoreId;
    @NonNull Integer helpfulVotes;
    @NonNull Integer totalVotes;
    @NonNull Date reviewDate;
    String reviewSummary;
    String reviewText;
}
