package com.lmig.itt.group16.group16hatandsglassesbackendspring.daos;

import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

@Repository
class ProductDaoDB implements ProductDao {

    @Autowired
    JdbcTemplate jdbc;

    public static final class ProductMapper implements RowMapper<Product> {

        @Override
        public Product mapRow(ResultSet rs, int index) throws SQLException {
            Product product = new Product();
            product.setAmazonProductId(rs.getString("amazonProductId"));
            product.setProductPrice(rs.getBigDecimal("productPrice"));
            product.setProductTitle(rs.getString("productTitle"));
            return product;
        }
    }

    @Override
    public String getProductIdByProductTitle(String productTitle) {
        Product product = getProductByProductTitle(productTitle);
        return product.getAmazonProductId();
    }

    @Override
    public Product getProductByProductTitle(String productTitle) {
        try {
            final String SELECT_PRODUCT_BY_TITLE = "SELECT * FROM product WHERE productTitle = ? LIMIT 1";
            return jdbc.queryForObject(SELECT_PRODUCT_BY_TITLE, new ProductMapper(), productTitle);
        } catch(DataAccessException ex) {
            return null;
        }
    }

    @Override
    public Product getProductByProductId(String productId) {
        try {
            final String SELECT_PRODUCT_BY_ID = "SELECT * FROM product WHERE amazonProductId = ? LIMIT 1";
            return jdbc.queryForObject(SELECT_PRODUCT_BY_ID, new ProductMapper(), productId);
        } catch(DataAccessException ex) {
            return null;
        }
    }

    //This will be used for getReviewStats()
    @Override
    public Integer getTotalProductCount() {
        final String COUNT_ALL_PRODUCTS = "SELECT COUNT(*) FROM product";
        return jdbc.queryForObject(COUNT_ALL_PRODUCTS, Integer.class);
    }

    @Override
    @Transactional
    public Product addProduct(Product product) {
        Product testProduct = getProductByProductId(product.getAmazonProductId());
        if (testProduct == null) {
            final String INSERT_PRODUCT = "INSERT INTO product(AmazonProductId, ProductPrice, ProductTitle) VALUES(?,?,?)";
            jdbc.update(INSERT_PRODUCT,
                    product.getAmazonProductId(),
                    product.getProductPrice(),
                    product.getProductTitle());

            return product;
        }
        return testProduct;
    }
}
