package com.lmig.itt.group16.group16hatandsglassesbackendspring.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Product {
    @NonNull String amazonProductId;
    BigDecimal productPrice;
    String productTitle;
}

