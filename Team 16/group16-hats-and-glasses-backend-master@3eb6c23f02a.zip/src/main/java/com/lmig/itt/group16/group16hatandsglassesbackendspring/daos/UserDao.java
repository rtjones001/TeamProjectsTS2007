package com.lmig.itt.group16.group16hatandsglassesbackendspring.daos;

import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.User;
import org.springframework.transaction.annotation.Transactional;

public interface UserDao {

    Integer getUserIdByAmazonUserId(String amazonUserId);
    User getUserByAmazonUserId(String amazonUserId);
    User getUserByUserId(Integer userId);

    // Create, should check if User exists before adding
    @Transactional
    User addUser (User user);
}
