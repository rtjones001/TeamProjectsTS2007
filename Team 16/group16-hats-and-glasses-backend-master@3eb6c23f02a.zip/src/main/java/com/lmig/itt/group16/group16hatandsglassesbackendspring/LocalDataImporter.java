package com.lmig.itt.group16.group16hatandsglassesbackendspring;

import com.lmig.itt.group16.group16hatandsglassesbackendspring.daos.*;
import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.*;
import java.sql.Date;

@Component
public class LocalDataImporter {

    private static final String PRODUCT_ID = "product/productId";
    private static final String PRODUCT_TITLE = "product/title";
    private static final String PRODUCT_PRICE = "product/price";
    private static final String REVIEW_USER_ID = "review/userId";
    private static final String REVIEW_PROFILE_NAME = "review/profileName";
    private static final String REVIEW_HELPFULNESS = "review/helpfulness";
    private static final String REVIEW_SCORE = "review/score";
    private static final String REVIEW_TIME = "review/time";
    private static final String REVIEW_SUMMARY = "review/summary";
    private static final String REVIEW_TEXT = "review/text";
    private static final String DELIMITER = ": ";

    /**
     * Replace with absolute path to data directory outside of version control.
     * We don't want to check in a 6GB text file!
     * Note that the files in this directory must have some multiple of 11 lines,
     * 10 for each entry and 1 for the delimiting new line so we don't split an entry across multiple files
     * you can split the data using bash like `split -l 4950000 myfile`
     * For testing with the in memoryDB, use the seed data in "src\\main\\resources\\db\\data\\":
     */
    private static final String PATH_NAME = String.valueOf(Paths.get("src","main","resources", "db", "data") + "\\");
//    private static final String PATH_NAME = "C:\\Users\\n1529282\\Documents\\dev\\TechStart\\FinalProject\\data\\";
    private static File data_dir = new File(PATH_NAME);
    private static String[] filenames;

    // In memory id caching for quick lookup during import
    // Lookup amazonProductId by productTitle
    private static Map<String, String> productIdMap = new HashMap<>();
    // Lookup userId by amazonUserId
    private static Map<String, Integer> userIdMap = new HashMap<>();
    // Lookup profileNameIds by profileNameValue
    private static Map<String, Integer> profileNameIdMap = new HashMap<>();
    // Lookup scoreId by scoreValue
    private static Map<BigDecimal, Integer> scoreIdMap = new HashMap<>();

    @Autowired
    private ProductDao productDao;
    @Autowired
    private ProfileNameDao profileNameDao;
    @Autowired
    private ReviewDao reviewDao;
    @Autowired
    private ScoreDao scoreDao;
    @Autowired
    private UserDao userDao;

    public void Import() {
        filenames = data_dir.list();
        long startTime = System.nanoTime();
        // Ran out of memory with Arrays.stream(filenames).parallel().forEach()
        // due to loading several ~500MB files into memory at a time.
        // Attempted to limit parallel stream to 2 threads
        // via: https://stackoverflow.com/questions/43655768/parallellize-a-for-loop-in-java-using-multi-threading
        // but it ended up being slower than sequential import.
        for (String filename : filenames) {
            long fileStartTime = System.nanoTime();
            System.out.printf("Parsing file %s\n", filename);
            List<List<String>> entries = GetEntries(filename);
            ParseEntries(entries);
            long fileEndTime = System.nanoTime();
            System.out.printf("Finished file %s in %d seconds\n", filename, (fileEndTime - fileStartTime) / 1000000000);
            System.out.printf("Total time elapsed: %d seconds\n", (fileEndTime - startTime) / 1000000000);
        }
        System.out.println("Import Complete!");
    }

    private void ParseEntries(List<List<String>> entries) {
        entries.parallelStream().forEach(entry -> {
            try {
                Map<String, String> entryKVP = parseEntry(entry);
                // e.g. B00002066I
                String productId = getProductId(entryKVP);
                Integer userId = getUserId(entryKVP.get(REVIEW_USER_ID));
                Integer profileNameId = getProfileNameId(entryKVP.get(REVIEW_PROFILE_NAME));
                Integer scoreId = getScoreId(entryKVP.get(REVIEW_SCORE));
                Review review = createReview(entryKVP, productId, scoreId, userId, profileNameId);
            } catch (SQLException  e) {
                e.printStackTrace();
            }
        });
    }

    private Review createReview(Map<String, String> entryKVP, String productId, Integer scoreId, Integer userId, Integer profileNameId) throws SQLException {
        String[] helpfulness = entryKVP.get(REVIEW_HELPFULNESS).split("/");
        Integer helpfulVotes = Integer.valueOf(helpfulness[0]);
        Integer totalVotes = Integer.valueOf(helpfulness[1]);
        // Dates are given in seconds, convert to milliseconds
        Long dateInMs = Long.parseLong(entryKVP.get(REVIEW_TIME)) * 1000;
        Date reviewDate = new Date(dateInMs);
        String reviewSummary = entryKVP.get(REVIEW_SUMMARY);
        String reviewText = entryKVP.get(REVIEW_TEXT);

        //no partial args constructor is exposed
        Review review = new Review();
        review.setHelpfulVotes(helpfulVotes);
        review.setTotalVotes(totalVotes);
        review.setReviewDate(reviewDate);
        review.setReviewSummary(reviewSummary);
        review.setReviewText(reviewText);
        review.setUserId(userId);
        review.setProfileNameId(profileNameId);
        review.setProductId(productId);
        review.setScoreId(scoreId);

        return reviewDao.addReview(review);
    }

    private Integer getScoreId(String scoreValueString) throws SQLException {
        BigDecimal scoreValue = new BigDecimal(scoreValueString);
        Integer scoreId = scoreIdMap.get(scoreValue);
        if (scoreId == null) {
            Score score = new Score();
            score.setScoreValue(scoreValue);
            scoreId = scoreDao.addScore(score).getScoreId();
            scoreIdMap.put(scoreValue, scoreId);
        }
        return scoreId;
    }

    private Integer getUserId(String amazonUserId) throws SQLException {
        Integer userId = userIdMap.get(amazonUserId);
        if (userId == null) {
            User user = new User();
            user.setAmazonUserId(amazonUserId);
            userId = userDao.addUser(user).getUserId();
            userIdMap.put(amazonUserId, userId);
        }
        return userId;
    }

    private Integer getProfileNameId(String profileNameValue) throws SQLException {
        Integer profileNameId = profileNameIdMap.get(profileNameValue);
        if (profileNameId == null) {
            ProfileName profileName = new ProfileName();
            profileName.setProfileNameValue(profileNameValue);
            profileNameId = profileNameDao.addProfileName(profileName).getProfileNameId();
            profileNameIdMap.put(profileNameValue, profileNameId);
        }
        return profileNameId;
    }

    private String getProductId(Map<String, String> entry) throws SQLException {
        String amazonProductId = entry.get(PRODUCT_ID);
        String productTitle = entry.get(PRODUCT_TITLE);
        String productPriceString = entry.get(PRODUCT_PRICE);
        String productId = productIdMap.get(productTitle);
        if (productId == null) {
            BigDecimal productPrice = null;
            try {
              productPrice = new BigDecimal(productPriceString);
            } catch (NumberFormatException e) {
                if (productPriceString.toLowerCase().equals("unknown")) {
                    // swallow exception, store unknown prices as null
                } else {
                    e.printStackTrace();
                }
            // malformed file?
            } catch (NullPointerException e) {
                e.printStackTrace();
            }
            Product product = new Product(amazonProductId, productPrice, productTitle);
            productId = productDao.addProduct(product).getAmazonProductId();
            productIdMap.put(amazonProductId, productId);
        }
        return productId;
    }

    /**
     * Takes a list of strings like "product/title: ah" and returns a
     * key value pair mapping like "product/title": "ah".
     * @param entry The list of strings to split.
     * @return Map of keys and values in the list.
     */
    private Map<String, String> parseEntry(List<String> entry) {
        Map<String, String> pairs = new HashMap<>();
        String[] pair;
        for (String line : entry) {
            pair = line.split(DELIMITER);
            pairs.put(pair[0], (pair.length > 1) ? pair[1] : null);
        }
        return pairs;
    }

    /**
     * Reads a file and groups the data contained into entries.
     * @param filename The path to the file we want to parse
     * @return A nested List of strings making up the individual entries contained in the file.
     */
    private List<List<String>> GetEntries(String filename) {
        List<String> lines = ReadFile(PATH_NAME + filename);
        List<List<String>> entries = new ArrayList<>();
        List<String> entry = new ArrayList<>();

        for (String line : lines) {
            if (line == null || line.isEmpty()) {
                entries.add(entry);
                entry = new ArrayList<>();
            } else {
                entry.add(line);
            }
        }
        return entries;
    }

    /**
     * Reads a file into a list
     * @param path The file to read
     * @return A List of Strings containing all the lines in the file
     */
    private List<String> ReadFile(String path) {
        List<String> lines = Collections.EMPTY_LIST;
        try
        {
            lines = Files.readAllLines(Paths.get(path));
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        return lines;
    }
}