package com.lmig.itt.group16.group16hatandsglassesbackendspring.daos;

import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.Score;
import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
public class UserDaoDB implements UserDao{

    @Autowired
    JdbcTemplate jdbc;

    public static final class UserMapper implements RowMapper<User> {

        @Override
        public User mapRow(ResultSet rs, int index) throws SQLException {
            User score = new User();
            score.setUserId(rs.getInt("userId"));
            score.setAmazonUserId(rs.getString("amazonUserId"));
            return score;
        }
    }

    @Override
    public Integer getUserIdByAmazonUserId(String amazonUserId) {
        User user = getUserByAmazonUserId(amazonUserId);
        return user.getUserId();
    }

    @Override
    public User getUserByAmazonUserId(String amazonUserId) {
        try {
            final String SELECT_USER_BY_AMAZON_ID = "SELECT * FROM user WHERE amazonUserId = ? LIMIT 1";
            return jdbc.queryForObject(SELECT_USER_BY_AMAZON_ID, new UserMapper(), amazonUserId);
        } catch(DataAccessException ex) {
            return null;
        }
    }

    @Override
    public User getUserByUserId(Integer userId) {
        try {
            final String SELECT_USER_BY_USER_ID = "SELECT * FROM user WHERE userId = ? LIMIT 1";
            return jdbc.queryForObject(SELECT_USER_BY_USER_ID, new UserMapper(), userId);
        } catch(DataAccessException ex) {
            return null;
        }
    }

    @Override
    @Transactional
    public User addUser (User user) {
        User testUser = getUserByAmazonUserId(user.getAmazonUserId());
        if (testUser == null) {
            final String INSERT_USER = "INSERT INTO User(AmazonUserId) VALUES(?)";
            jdbc.update(INSERT_USER,
                    user.getAmazonUserId());

            int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
            user.setUserId(newId);
            return user;
        }
        return testUser;
    }
}
