package com.lmig.itt.group16.group16hatandsglassesbackendspring.daos;

import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.Score;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

public interface ScoreDao {

    Integer getScoreIdByScoreValue(BigDecimal scoreValue);
    Score getScoreByScoreValue(BigDecimal scoreValue);
    Score getScoreByScoreId(Integer scoreId);

    // Create, should check if Score exists before adding
    @Transactional
    Score addScore (Score score);
}
