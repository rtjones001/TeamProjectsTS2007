package com.lmig.itt.group16.group16hatandsglassesbackendspring.daos;

import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.ProfileName;
import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
public class ProfileNameDaoDB implements ProfileNameDao {

    @Autowired
    JdbcTemplate jdbc;

    public static final class ProfileMapper implements RowMapper<ProfileName> {

        @Override
        public ProfileName mapRow(ResultSet rs, int index) throws SQLException {
            ProfileName profile = new ProfileName();
            profile.setProfileNameId(rs.getInt("profileNameId"));
            profile.setProfileNameValue(rs.getString("profileNameValue"));
            return profile;
        }
    }

    @Override
    public Integer getProfileNameIdByProfileNameValue(String profileNameValue) {
        ProfileName profile = getProfileNameByProfileNameValue(profileNameValue);
        return profile.getProfileNameId();
    }

    @Override
    public ProfileName getProfileNameByProfileNameValue(String profileNameValue) {
        try {
            final String SELECT_PROFILE_BY_NAME = "SELECT * FROM ProfileName WHERE profileNameValue = ? LIMIT 1";
            return jdbc.queryForObject(SELECT_PROFILE_BY_NAME, new ProfileMapper(), profileNameValue);
        } catch(DataAccessException ex) {
            return null;
        }
    }

    @Override
    public ProfileName getProfileNameByProfileNameId(Integer profileNameId) {
        try {
            final String SELECT_PROFILE_BY_ID = "SELECT * FROM ProfileName WHERE profileNameId = ? LIMIT 1";
            return jdbc.queryForObject(SELECT_PROFILE_BY_ID, new ProfileMapper(), profileNameId);
        } catch(DataAccessException ex) {
            return null;
        }
    }

    @Override
    @Transactional
    public ProfileName addProfileName (ProfileName profileName) {
        ProfileName testName = getProfileNameByProfileNameValue(profileName.getProfileNameValue());
        if (testName == null) {
            final String INSERT_PROFILE_NAME = "INSERT INTO ProfileName(ProfileNameValue) VALUES(?)";
            jdbc.update(INSERT_PROFILE_NAME,
                    profileName.getProfileNameValue());

            int newId = jdbc.queryForObject("SELECT LAST_INSERT_ID()", Integer.class);
            profileName.setProfileNameId(newId);
            return profileName;
        }
        return testName;
    }
}
