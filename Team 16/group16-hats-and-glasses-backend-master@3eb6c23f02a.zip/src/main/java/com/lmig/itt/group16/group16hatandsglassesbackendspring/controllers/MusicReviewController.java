package com.lmig.itt.group16.group16hatandsglassesbackendspring.controllers;

import com.lmig.itt.group16.group16hatandsglassesbackendspring.models.*;
import com.lmig.itt.group16.group16hatandsglassesbackendspring.daos.*;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/music")
@CrossOrigin (origins = {"http://localhost:3000", "https://group16-hats-and-glasses-backend-development.us-east-1.np.paas.lmig.com"}, allowCredentials = "true")
public class MusicReviewController {

    @Autowired
    private ReviewDao dao;

    /*
Retrieving all Reviews
HTTP Method: GET
URL: /api/music/reviews?limit={numberOfRecords}&offset={startPosition}
RequestBody: None
ResponseBody: JSON string containing the requested reviews data
     */
    @GetMapping("/reviews")
    public List<Map<String,String>> all(@RequestParam(defaultValue = "1000") int limit, @RequestParam(defaultValue = "0") int offset) {
        if (limit > 1000) {
            limit = 1000;
        }
        return dao.getAllReviews(limit, offset);
    }

    /*
Retrieving all Scores
HTTP Method: GET
URL: /api/music/scores
RequestBody: None
     */
    @GetMapping("/scores")
    public Map<Float, Integer> getAllScores() {
        return dao.getReviewScoreCount();
    }

    /*
Retrieving Product by ProductId
HTTP Method: GET
URL: /api/music/product/productId/{productId}
RequestBody: None
ResponseBody:
     */
    // TODO: try to find a better solution than JSONObject.toString()
    @GetMapping("/product/productId/{productId}")
    public Map<String, Map<String, String>>  getProductByProductId(@PathVariable String productId) throws JSONException {
        return dao.getScoresAndDatesByProductId(productId);
    }

    /*
Retrieving Product by ProductName
HTTP Method: GET
URL: /api/music/product/productName/{productName}
RequestBody: None
ResponseBody:
     */
    @GetMapping("/product/productName/{productName}")
    public Map<String, Map<String, String>>  getProductByProductName(@PathVariable String productName) throws JSONException {
        return dao.getScoresAndDatesByProductName(productName);
    }

    /*
Retrieving Stats for All Products
HTTP Method: GET
URL: /api/music/stats
RequestBody: None
ResponseBody:
     */
    @GetMapping("/stats")
    public Map<String, String> getReviewStats() throws JSONException {
        return dao.getReviewStats();
    }
  /*
Retrieving Top Ten Most Reviewed Products
HTTP Method: GET
URL: /api/music/stats
RequestBody: None
ResponseBody:
     */
    @GetMapping("/product/top")
    public List<Map<String, String>> getMostReviewed() throws JSONException {
        return dao.getMostReviewedProducts();
    }

    @GetMapping("/helloworld")
    public String helloWorld() {
        return "Hello World!";
    }

}
