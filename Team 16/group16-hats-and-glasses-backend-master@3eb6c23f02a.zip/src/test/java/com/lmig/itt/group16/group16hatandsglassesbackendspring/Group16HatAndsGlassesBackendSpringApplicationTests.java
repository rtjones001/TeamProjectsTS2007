package com.lmig.itt.group16.group16hatandsglassesbackendspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Group16HatAndsGlassesBackendSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
